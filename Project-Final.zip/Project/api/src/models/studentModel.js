class Student {
    constructor(name, email, course) {
        this.name = name;
        this.email = email;
        this.course = course;
    }
}

module.exports = Student;